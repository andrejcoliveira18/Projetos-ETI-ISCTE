#!/bin/bash


###############################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos
##
## Aluno Nº:98412       Nome: André João Chagas de Oliveira
## Nome do Módulo: lista_cidadaos.sh
## Descrição/Explicação do Módulo: Em primeiro lugar, verifiquei se o ficheiro listagem.txt existe
## Depois utilizei o awk e consegui fazer tudo o que era 
## pedido numa só linha. A função -F permite "adicionar" tipos de espaçamento entre
## colunas, assim, para obter o numero de utente, utilizei a função do awk NR que devolve 
## o número da linha e somei 10000 para corresponder ao enunciado. Depois, fazendo algumas
## alterações na ordem das colunas obtive o resultado pretendido. Por fim, redirecionei essa informação
## para o ficheiro cidadaos.txt e fiz cat cidadaos.txt para a função fazer output dessa mesma informação. 
##
###############################################################################

if ! [ -e listagem.txt ];then
    echo ""
    echo "Erro: é necessário o ficheiro 'listagem.txt' existir nesta diretoria"
    echo ""
    exit
fi

awk -F' \| |:|-' '{print (NR)+10000 ":" $2 ":" 2021-$6 ":" $8 ":" $10 ":0"}' listagem.txt > cidadaos.txt

cat cidadaos.txt
 