#!/bin/bash


###############################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos
##
## Aluno Nº:98412       Nome: André João Chagas de Oliveira 
## Nome do Módulo: stats.sh
## Descrição/Explicação do Módulo: Utlizei a função case para cobrir qualquer hipótese
## que possa ser dada pelo utilizador. Cidadaos) Novamente, validei o argumento usando a função test
## garantindo que é dada uma cidade pelo utilizador, depois utilizando o grep em conjunto com wc, obtive
## o número de occorrências da cidade no ficheiro cidadaos.txt. Registados) Neste caso, fiz um ciclo while
## que percorre o ficheiro cidadaos.txt e usando test, a função "imprime" todas as linhas cuja coluna 4
## é maior que 59. Enfermeiros) Com a função awk, procura todas as linhas que tenham a 6ª coluna a 1 e imprime
## os nomes dos enfermeiros. Em caso do utilizador selecionar outra opção que não é válida, aparece a mensagem de erro.
##
###############################################################################

if ! [ -e cidadaos.txt ]; then
  echo "Erro: Tem de listar os cidadãos primeiro."
  exit
fi

case $1 in 
    cidadaos) if [ -z "$2" ]; then
                echo "Erro: Tem de inserir uma cidade"
              fi

              n_cidadaos=$(grep "$2" cidadaos.txt | wc -l)
              echo "O número de cidadãos registados em $2 é $n_cidadaos"
              ;;
    registados) while IFS= read linha; do
                  idade=$(echo $linha | awk -F: '{print $3}')
                  if [ $idade -gt 59 ]; then
                    nome=$(echo $linha | awk -F: '{print $2}')
                    num=$(echo $linha | awk -F: '{print $1}')
                    echo "$nome:$num:$idade" >> up60.txt
                  fi
                done < cidadaos.txt
                sort -nr -t: -k3 up60.txt
                rm up60.txt
                ;;
    enfermeiros) awk -F: '$5~"1" {print  $2}' enfermeiros.txt;;
    *) echo "Erro: Opção inválida, deve inserir uma das seguintes opções [cidadaos <localidade> | registados | enfermeiros]";;
esac

