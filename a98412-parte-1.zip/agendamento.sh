#!/bin/bash


###############################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos
##
## Aluno Nº:98412       Nome: André João Chagas de Oliveira 
## Nome do Módulo: agendamento.sh
## Descrição/Explicação do Módulo: A primeira função verifica se o ficheiro agenda.txt 
## existe e se existir apaga-o. Depois utilizei dois ciclos um dentro do outro em que o 
## primeiro lê o enfermeiros.txt linha a linha e se nessa linha houver enfermeiros disponíveis
## guarda o nome, numero de cédula e o CS, o segundo ciclo analisa também linha a linha o ficheiro
## cidadaos.txt, em caso de a cidade do cidadao corresponder ao CS do enfermeiro, é agendada a vacinação.
##
###############################################################################

if [ -e agenda.txt ]; then
    rm agenda.txt
fi

if [ ! -e cidadaos.txt ]; then 
    echo "Erro: Tem de listar os cidadãos primeiro"
    exit
fi

if [ ! -e enfermeiros.txt ]; then 
    echo "Não há enfermeiros disponíveis"
    exit
fi

disp=$(awk -F: '$5~"1" {print $1}' enfermeiros.txt | wc -l)

if [ $disp -eq 0 ]; then
    echo "Não há enfermeiros disponíveis"
    exit
fi

while IFS= read linha; do
    disp=$(echo $linha | awk -F: '{print $5}')
    if [ $disp -eq 1 ]; then 
       nome_enf=$(echo $linha | awk -F: '{print $2}')
       cedula=$(echo $linha | awk -F: '{print $1}')
       CS=$(echo $linha | awk -F: '{print $3}')
        while IFS= read linha2; do
            cidade=$(echo $linha2 | awk -F: '{print $4}')
            if [ "$CS" == "CS$cidade" ]; then
                nome_cid=$(echo $linha2 | awk -F: '{print $2}')
                num_utente=$(echo $linha2 | awk -F: '{print $1}')
                data=$(date +%F)
                echo "$nome_enf:$cedula:$nome_cid:$num_utente:$CS:$data" >> agenda.txt
            fi 
        done < cidadaos.txt
    fi        
done < enfermeiros.txt

cat agenda.txt
