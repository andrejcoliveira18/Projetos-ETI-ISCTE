#!/bin/bash

###############################################################################
## ISCTE-IUL: Trabalho prático de Sistemas Operativos
##
## Aluno Nº:98412       Nome: André João Chagas de Oliveira 
## Nome do Módulo: adiciona_enfermeiros.sh
## Descrição/Explicação do Módulo: Para começar, fiz as validações dos argumentos
## usando a função test. Usando a mesma função, verifiquei os pontos 2.1.1 e 2.2.2 
## do enunciado. Por fim, redirecionei os argumentos pela ordem pretendida para o
## ficheiro enfermeiros.txt.
##
###############################################################################

touch enfermeiros.txt

if [ $# -ne 4 ]; then
    echo "Erro: Síntaxe:$0:<nome>:<número de cédula profissional>:<centro saúde associado>:<nº de vacinações efetuadas>:<disponibilidade>"
    exit
fi

if ! [[ "$2" =~ ^[0-9]+$ ]]; then
    echo "Erro, o valor deve ser um número inteiro positivo"
    exit -2
fi

CS=$(echo $3 | grep CS | awk '{print $1}' | wc -w)

if [ $CS -ne 1 ]; then
    echo "Erro: Insira o centro de saúde com o formato correto (Ex:CSLisboa)"
    exit
fi

if [ $4 -ne 0 ] && [ $4 -ne 1 ]; then 
    echo "Erro: Insira a disponibiliade corretamente (0-indisponível, 1-disponível)"
    exit
fi

ocorrencias=$(grep "$3" enfermeiros.txt | wc -l)
if [ $ocorrencias -ge 1 ]; then
    echo "Erro: O Centro de Saúde introduzido já tem um enfermeiro registado"
    exit
fi

cedula=$(grep $2 enfermeiros.txt | wc -l)
if [ $cedula -ne 0 ]; then
    echo "Erro: Já está inscrito noutro Centro de Saúde"
    exit
fi



echo "$2:$1:$3:0:$4" >> enfermeiros.txt

cat enfermeiros.txt



