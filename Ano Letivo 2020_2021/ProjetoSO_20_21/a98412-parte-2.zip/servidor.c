/******************************************************************************
 ** ISCTE-IUL: Trabalho prático de Sistemas Operativos
 **
 ** Aluno Nº:98412       Nome: André João Chagas de Oliveira 
 ** Nome do Módulo: servidor.c
 ** Descrição/Explicação do Módulo: Devido a ser um ficheiro bastante extenso, optei por comentar ao longo
 ** do código para facilitar a leitura e compreensão das minhas ideias para o código. A realização desta
 ** parte do projeto foi feita com recurso aos exercicios das aulas práticas e alguma pesquisa na internet.
 **
 ******************************************************************************/
// Bibliotecas necessárias à realização do trabalho
#include "common.h"  
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>

Vaga vagas[NUM_VAGAS]; // Array de vagas para vacinação
Cidadao c; // Variável global cidadão
int NumEnfermeiros; // Variável global Numero de Enfermeiros
Enfermeiro* enfermeiros; // Variável global enfermeiros

//S2Aux
void Num_Enfermeiros(){ // Função que altera a variável global NumEnfermeiros para o número de enfermeiros do ficheiro
    FILE* f2 = fopen("enfermeiros.dat","r"); // Abre o ficheiro "enfermeiros.dat" para leitura
    fseek( f2, 0, SEEK_END ); // Posiciona-se no fim do ficheiro
    long tamanho = ftell( f2 ); // ftell() devovlve a posição do cursor
    fclose( f2 ); // Fecha o ficheiro
    NumEnfermeiros = (int) (tamanho / sizeof(Enfermeiro)); // Divide-se o tamanho total do ficheiro pelo tamanho de 1 enfermeiro e obtém-se o número de enfermeiros
}

//S2Aux
void cria_Enfermeiros(){
    enfermeiros = (Enfermeiro *) malloc( NumEnfermeiros * sizeof(Enfermeiro)); // Define a estrutura de dados dinâmica em memória
}


int primeira_vaga_disponivel(){ // Devolve o índice da primeira vaga disponível
    for(int i = 0; i < NUM_VAGAS; i++){
        if(vagas[i].index_enfermeiro == -1){
            return i;
            break;
        }
    }
}

int num_vagas(){ // Devolve o número total de vagas
    int count = 0;
    for(int i = 0; i < NUM_VAGAS;i++){
        if(vagas[i].index_enfermeiro == -1){
            count++;
        }
    }
    return count;
}

void acorda(int sinal){ // Função handler do sinal SIGCHLD
    int pid_enf_atual = wait(NULL); // Guarda o PID do processo que acabou de terminar
    int index_enf_atual = -1; // Iniciação de variável  que vai guardar o indice do enfermeiro
    int vaga_enf = -1; // Iniciação de variável  que vai guardar o indice da vaga
    for(int i = 0; i < NUM_VAGAS;i++){
        if(pid_enf_atual == vagas[i].PID_filho){// Compara os PID's na lista de vagas...
            index_enf_atual = vagas[i].index_enfermeiro;  // ... guarda o indice do enfermeiro
            vaga_enf = i; // ... e guarda o valor da vaga atual
            break; // sai do loop
        }
    }

    //S5.3.1
    vagas[vaga_enf].index_enfermeiro = -1; // Limpa a vaga, ou seja, uda o index do enfermeiro da vaga para -1
    sucesso("S5.5.3.1) Vaga %d que era do servidor dedicado %d libertada", vaga_enf, vagas[vaga_enf].PID_filho); // Mensagem de sucesso
    
    //S5.5.3.2
    enfermeiros[index_enf_atual].disponibilidade = 1; // Altera a disponinbilidade do enfermeiro para 1
    sucesso("S5.5.3.2) Enfermeiro %d atualizado para disponível", index_enf_atual); // Mensagem de sucesso
    
    //5.5.3.3
    enfermeiros[index_enf_atual].num_vac_dadas ++; // Aumenta o num de vacinas dadas
    sucesso("S5.5.3.3) Enfermeiro %d atualizado para %d vacinas dadas", index_enf_atual, enfermeiros[index_enf_atual].num_vac_dadas );
    
    //5.5.3.4
    FILE *f = fopen("enfermeiros.dat", "r+"); // Abre o ficheiro para escrita e leitura
    fseek(f, (index_enf_atual-1)*sizeof(Enfermeiro),SEEK_SET ); // Coloca-se na posição antes para escrever 
    fwrite(&enfermeiros[index_enf_atual], sizeof(enfermeiros[index_enf_atual]), 1, f); // Reescreve o enfermeiro com as alterações
    fclose(f); // Fecha o ficheiro
    sucesso("S5.5.3.4) Ficheiro FILE_ENFERMEIROS %d atualizado para %d vacinas dadas", index_enf_atual, enfermeiros[index_enf_atual].num_vac_dadas); // Mensagem de sucesso
    
    //5.5.3.5
    sucesso("S5.5.3.5) Retorna"); // Volta ao que estava a fazer
}

void trata_SIGTERM(){ //função handler do sinal SIGTERM
    //5.6.1
    sucesso("5.6.1) SIGTERM recebido, servidor dedicado termina Cidadão"); // Mensagem de sucesso
    kill(c.PID_cidadao, SIGTERM); // Envia SIGTERM ao processo cidadao
}

void trata_SIGINT(){ // Função handler do sinal SIGINT
    //S6
    for(int i = 0; i < NUM_VAGAS;i++){
        if(vagas[i].index_enfermeiro != -1){
            kill(vagas[i].PID_filho, SIGTERM); // Procura nas vagas e envia a todos os PID's um sinal SIGTERM
        }
    }
    sucesso("S6) Servidor Terminado"); // Mensagem de suceso
    remove("servidor.pid"); // Elimina o ficheiro 
    exit(0); // Termina o processo
}

void cria_filho(int vaga){ 
    int filho = 0; 
    filho = fork(); // Cria o processo filho
    if(filho < 0){ // Se der erro...
        erro("S5.4) Não foi possível criar o servidor dedicado"); // MEnsagem de erro
    }

    if (filho == 0){ // Se for o processo filho...
        //5.4
        sucesso("S5.4) Servidor dedicado %d criado para o pedido %d", filho, c.PID_cidadao); // Mensagem de sucesso
        
        //5.6.1
        signal(SIGTERM, trata_SIGTERM); // Arma o sinal SIGTERM
        
        //5.6.2
        kill(c.PID_cidadao, SIGUSR1); // Envia SIGUSR1 ao processo cidadao
        sucesso("5.6.2) Servidor dedicado inicia consulta de vacinação"); // Mensagem de sucesso
        
        //5.6.3
        sleep(TEMPO_CONSULTA); // Espera TEMPO_CONSULTA 
        sucesso("5.6.3) Vacinação terminada para o cidadão com o pedido nº %d", c.PID_cidadao); // Mensagem de sucesso
        
        //5.6.4
        kill(c.PID_cidadao,SIGUSR2); // Envia sinal SIGUSR2 ao processo cidadao
        sucesso("S5.6.4) Servidor dedicado termina consulta de vacinação"); // Mensagem de suceso
        exit(0); // Termina o processo filho

    }else{ // Se for o processo pai...
        //S5.5.1)
        vagas[vaga].PID_filho = filho; // Associa à vaga o PID do filho
        sucesso("S5.5.1) Servidor dedicado %d na vaga %d", filho, vaga); // Mensagem de sucesso 

        //S5.5.2
        sucesso("S5.5.2) Servidor aguarda fim do servidor dedicado %d", filho); // Mensagem de sucesso

    }
}

void trata_cidadao(){ // Função handler do sinal SIGUSR1
    //S5.1
    FILE *cidadao; // Pointer para ficheiro
    cidadao = fopen("pedidovacina.txt", "r"); // Abre o ficheiro para leitura
    if(access("pedidovacina.txt", F_OK) != 0){
        erro("S5.1) Não foi possivel abrir o ficheiro FILE_PEDIDO_VACINA"); // Se o ficheiro não existir, aparece a mensagem de erro
        exit(0);
    }
    if(!cidadao){
        erro("S5.1) Não foi possível ler o ficheiro FILE_PEDIDO_VACINA"); // Se a abertura der erro, aparece mensagem de erro
    }
    fscanf(cidadao,"%d:%100[^:]:%d:%100[^:]:%10[^:]:%d:%d", &c.num_utente, &c.nome, &c.idade, &c.localidade, &c.nr_telemovel, &c.estado_vacinacao, &c.PID_cidadao); // Lê as informações diretamente de um ficheiro para a varável cidadão
    sucesso("S5.1) Dados cidadão: %d; %s; %d; %s; %s; 0", c.num_utente, c.nome, c.idade, c.localidade, c.nr_telemovel); // Mensagem de sucesso 

    char CS[100] = "CS"; // String CS para poder comparar
    strcat(CS, c.localidade); // Concatenar as strings CS e localidade para poder comparar com o enfermeiro
    for(int i = 0;i < NumEnfermeiros;i++){ // Percorrer a lista de enfermeiros
        
        //5.2
        if(strcmp(enfermeiros[i].CS_enfermeiro,CS) == 0){ // Se o CS corresponder com a localidade, continua
           
           //5.2.1
           if(enfermeiros[i].disponibilidade == 1){ // Se esse enfermeiro tiver disponibilidade a 1
                sucesso("S5.2.1) Enfermeiro %d disponível para o pedido %d", i, c.PID_cidadao); // Como o enf está disponível aparece mensagem de sucesso
                
                //5.2.2
                if(num_vagas() != 0){ // Se houver vagas, continua... (A função num_vagas() devolve o número total de vagas)
                    sucesso("S5.2.2) Há vaga para vacinação para o pedido %d", c.PID_cidadao); // Como há vagas, aparece a mensagem de suceso 
                    
                    //5.3
                    int vaga_atual = primeira_vaga_disponivel(); // Guarda o índice da primeira vaga disponível
                    vagas[vaga_atual].cidadao = c; // Associa o cidadão à vaga
                    vagas[vaga_atual].index_enfermeiro = i; // Associa o index do enfermeiro à vaga
                    enfermeiros[i].disponibilidade = 0; // Altera a disponíbilidade do enfermeiro para 0
                    sucesso("S5.3) Vaga nº %d preenchida para o pedido %d", vaga_atual, c.PID_cidadao); // Mensagem de sucesso 
                    
                    //5.4
                    cria_filho(vaga_atual); // Função que cria o processo filho dedicado à vacinação
                    break; // Assim que encontra um enfermeiro que cumpre todos os critérios sai do loop

                }else{ // Caso não haja vagas...
                    
                    //5.2.2
                    erro("S5.2.2) Não há vaga para vacinação para o pedido %d", c.PID_cidadao); // Mensagem de erro caso não haja
                    kill(c.PID_cidadao, SIGTERM); // Envia um sinal SIGTERM ao PID do processo cidadão
                    break; // Sai do loop

                }
           }else{// Caso o enfermeiro dessa localidade não esteja disponivel...
                
                //5.2.1
                erro("S5.2.1) Enfermeiro %d indisponível para o pedido %d para o Centro de Saúde %s", i, c.PID_cidadao, enfermeiros[i].CS_enfermeiro);// Mensagem de erro
                kill(c.PID_cidadao,SIGTERM); // Envia um sinal SIGTERM ao processo cidadão
                break; // Sai do loop

           }
        }
    }    
}

int main() {
    //S1
    int pid = getpid(); // Associa o PID do processo atual a uma variável do tipo inteiro
    FILE *f; // Cria um ponteiro para um ficheiro
    f = fopen("servidor.pid","w"); // Abre o ficheiro para escrita e associa ao ponteiro anterior
    if(!f) erro("S1) Não consegui registar o servidor"); // Se a abertura para escrita falhar, aparece a mensagem de erro
    fprintf(f,"%d",pid); // Escreve no ficheiro o PID
    fclose(f); // fecha o ficheiro
    sucesso("S1) Escrevi no ficheiro FILE_PID_SERVIDOR o PID: %d", pid); // Mensagem de sucesso
    
    //S2
    if(access("enfermeiros.dat", F_OK) == 0){
        Num_Enfermeiros(); // Função que define o número de enfermeiros
        cria_Enfermeiros(); // Função que cria a estrutura de dados dinâmica
        FILE *f2; // Ponteiro para um ficheiro
        f2 = fopen("enfermeiros.dat", "r"); // Abre o ficheiro enfermeiros.dat para leitura
        if(!f2) erro("S2) Não consegui ler o ficheiro FILE_ENFERMEIROS!"); // Caso a abertura dê erro, mensagem de erro
        fseek(f2,0,SEEK_SET); //Posiciona o cursor no inicio do ficheiro para evitar erros 
        fread(enfermeiros,sizeof(Enfermeiro), NumEnfermeiros,f2); //Lê o ficheiro binário e associa À estrutura de dados dinâmica
        long tamanho = NumEnfermeiros*sizeof(Enfermeiro);
        sucesso("S2) Ficheiro FILE_ENFERMEIROS tem %ld bytes, ou seja, %d enfermeiros", tamanho, NumEnfermeiros); // Mensagem de sucesso
        fclose(f2); // Fecha o ficheiro 
    }else{
        erro("S2) Não consegui ler os ficheiro FILE_ENFERMEIROS!");  // Caso o ficheiro não exista, mensagem de erro
    }
    
    //S3
    for(int i=0;i < NUM_VAGAS;i++){ // Percorre todas as vagas
        vagas[i].index_enfermeiro = -1; // Define o index_enfermeiro de cada vaga a -1
    }
    sucesso("S3) Iniciei a lista de %d vagas", NUM_VAGAS); // Mensagem de sucesso

    //S4
    signal(SIGUSR1,trata_cidadao); // Arma o sinal SIGUSR1
    sucesso("S4) Servidor espera pedidos"); //Mensagem de sucesso
        
    //5.5.2
    signal(SIGCHLD, acorda); // Arma o sinal SIGCHLD

    //6
    signal(SIGINT, trata_SIGINT); // Arma o sinal SIGINT (Ctrl + C)
    
    while(1) pause(); // Coloca o processo em espera passiva
}
