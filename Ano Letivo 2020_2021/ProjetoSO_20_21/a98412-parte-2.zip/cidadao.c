/******************************************************************************
 ** ISCTE-IUL: Trabalho prático de Sistemas Operativos
 **
 ** Aluno Nº:98412       Nome: André João Chagas de Oliveira 
 ** Nome do Módulo: cidadao.c
 ** Descrição/Explicação do Módulo: Devido a ser um ficheiro bastante extenso, optei por comentar ao longo
 ** do código para facilitar a leitura e compreensão das minhas ideias para o código.A realização desta
 ** parte do projeto foi feita com recurso aos exercicios das aulas práticas e alguma pesquisa na internet.
 **
 ******************************************************************************/
// Bibliotecas necessárias à realização do trabalho
#include "common.h"
#include "utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

Cidadao c; // Variável global cidadão 

void cancela(){ // Função handler do sinal SIGINT
    sucesso("C5) O cidadão cancelou a vacinação, o pedido nº %d foi cancelado", c.PID_cidadao); // Mensagem de sucesso
    remove("pedidovacina.txt"); // Elimina o ficheiro "pedidovacina.txt"
    exit(0); // Termina o processo
}

void vacinacao_em_curso(){ // Função handler do sinal SIGUSR1
    sucesso("C7) Vacinação do cidadão com o pedido nº %d em curso", c.PID_cidadao); // Mensagem de sucesso que informa que a vacinação está em curso
    remove("pedidovacina.txt"); // Remove o ficheiro "pedidovacina.txt"
    pause(); // Fica em pausa à espera de novos sinais
}

void vacinacao_concluida(){ // Função handler do sinal SIGUSR2
    sucesso("C8) Vacinação do cidadão com o pedido nº %d concluída", c.PID_cidadao); // Mensagem de sucesso que informa que a vacinação foi concluida
    exit(0); // Termina o processo cidadao
}

void vacinacao_cancelada(){ // Função handler do sinal SIGTERM
    sucesso("C9) Não é possível vacinar o cidadão no pedido nº %d", c.PID_cidadao); // Mensagem de sucesso que informa que a vacinação foi cancelada
    remove("pedidovacina.txt"); // Elimina o ficheiro "pedidovacina.txt"
    exit(0);
}

void handler(int sinal){ // Função vazia apenas para ser possível executar
}


int main(){
    
    //C1
    printf("\n......Insira os seus dados.....\n"); //
    printf("\nNúmero de utente: "); // Pede o nº de utente ao utilizador
    scanf(" %d", &c.num_utente); // Faz scan do nº de utente
    printf("\nNome: "); // Pede o nome ao utilizador
    scanf(" %100[^\n]", &c.nome); // Faz scan do nome e associa diretamente ao cidadão
    printf("\nIdade: "); // Pede a idade ao utilizador
    scanf(" %d", &c.idade); // Faz scan da idade e associa diretamente ao cidadão
    printf("\nLocalidade: "); // Pede a localidade ao utilizador
    scanf(" %100[^\n]", &c.localidade); // Faz scan da localidade e associa diretamente ao cidadão
    printf("\nNúmero de Telemóvel: "); // Pede o nº de telemóvel
    scanf(" %s", &c.nr_telemovel); // Faz scan do nº de telemóvel e associa diretamente ao cidadão
    // Apresenta mensagem de sucesso com os dados do utilizador 
    sucesso("C1) Dados Cidadão: %d; %s; %d; %s; %s; 0",c.num_utente, c.nome, c.idade, c.localidade, c.nr_telemovel );

    //C2
    c.PID_cidadao = getpid(); //Associa ao cidadão o PID do processo atual
    sucesso("C2) PID cidadão: %d", c.PID_cidadao); //Apresenta mensagem de sucesso com o PID
    c.estado_vacinacao = 0; //Estado de vacinação do cidadão iniciado a 0
    
    //C3 (C/ extra points)
    while(access("pedidovacina.txt", F_OK) == 0){ // Verifica se o ficheiro ainda existe
        erro("C3) Não é possível iniciar o processo de vacinação neste momento"); // Mensagem de erro
        alarm(5); //"Dorme" por 5 segundos e envia um sinal a si proprio
        signal(SIGALRM, handler); //Recebe o sinal
        pause(); // Espera passiva
    }
    sucesso("C3) Ficheiro FILE_PEDIDO_VACINA pode ser criado"); // Quando o ficheiro deixa de existir, sai do loop e aparece a mensagem de sucesso

    //C4
    FILE *fp; // Cria um ponteiro para um ficheiro
    fp = fopen ("pedidovacina.txt", "w"); // Abre o ficheiro para leitura
    if(!fp) { //CAso não seja possivel criar o ficheiro
        erro("Não é possível criar o ficheiro FILE_PEDIDO_VACINA"); // Mensagem de erro
        exit(0); // Termina o processo
    }
    fprintf(fp,"%d:%s:%d:%s:%s:%d:%d", c.num_utente, c.nome, c.idade, c.localidade, c.nr_telemovel, c.estado_vacinacao, c.PID_cidadao); // Escreve no ficheiro as informações do cidadão
    sucesso("C4) Ficheiro FILE_PEDIDO_VACINA criado e preenchido"); // Mensagem de sucesso 
    fclose(fp); // Fecha o ficheiro
    
    //C5
    signal(SIGINT,cancela); // Arma o sinal SIGINT (Ctrl + C)
    
    //C6
    if(access("servidor.pid", F_OK) == 0){ // Verifica se o ficheiro "servidor.pid" existe
        FILE *f; // Cria um pointer para um ficheiro
        f = fopen("servidor.pid","r"); // Abre o ficheiro "servidor.pid" para leitura
        char string[10]; // String para colocar o pid do servidor
        fscanf(f,"%s", &string); // Lê o ficheiro e retira o PID
        int pid_servidor = atoi(string); // Transforma a string com o PID num inteiro
        kill(pid_servidor,SIGUSR1); // Envia um sinal SIGUSR1 ao processo servidor
        sucesso("C6) Sinal enviado ao servidor: %d", pid_servidor); // Mensagem de sucesso 
    }else{
        erro("C6) Não existe ficheiro FILE_PID_SERVIDOR!"); // Mensagem de erro caso o ficheiro não exista
        exit(0); // Termina o processo
    }
    
    //C7
    signal(SIGUSR1, vacinacao_em_curso); // Arma o sinal SIGUSR1

    //C8
    signal(SIGUSR2, vacinacao_concluida); // Arma o sinal SIGUSR2

    //C9
    signal(SIGTERM, vacinacao_cancelada); // Arma o sinal SIGTERM
    while (1) pause(); // Coloca o processo em espera passiva
}
