%next_player(Player1, Player2) - permite saber qual � o pr�ximo jogador
next_player(1,2).
next_player(2,1).

%play_game/0
% Este predicado come�a por criar um tabuleiro com a dimensao 6x6 e
% validar a jogada do computador (player 1).
play_game():-
    initial_board(6, 6, B0),
    play(1,B0).

%*********AL�NEA A*************%
%initial_board(NumRows, NumColumns, Board)
% Este predicado cria um tabuleiro Board com NumRows linhas e NumColumns
% colunas.

initial_board(0, _, []).
initial_board(NumRows, NumColumns, [H|T]):-
    N1 is NumRows - 1,
    vector_of_zeros(NumColumns,H),
    initial_board(N1, NumColumns, T).

vector_of_zeros(0, []).
vector_of_zeros(NumColumns, [0|Tail]):-
    N2 is NumColumns - 1,
    vector_of_zeros(N2, Tail).


%*********AL�NEA B*************%
% print_board(Board)
% Este predicado imprime para a consola o tabuleiro board.

print_board([]).
print_board([Head|Tail]):-
    print_list(Head),nl,
    print_board(Tail).

print_list([]).
print_list([H|T]):-
    write(H),
    print_list(T).

%*********AL�NEA C*************%
%valid_move(X,Y,Board)
% Verifica se a posi��o (X,Y) � v�lida, ou seja, se naquela posi��o
% existe um zero.

valid_move(X,Y,Board):-
    getX(Board,X,X1),
    getY(X1,Y,Y1),
    Y1=0.

getY([H|_],0,H).
getY([_|T],Y,L):-
    Y1 is Y -1,
    getY(T,Y1,L).

getX([H1|_], 0, H1).
getX([_|T1],X,L1):-
    X1 is X - 1,
    getX(T1,X1,L1).

%*********AL�NEA D*************%
% add_move(Player,X,Y,InitialBoard,FinalBoard).
% Adiciona o n�mero do jogador � posi��o (X,Y) do tabuleiro

add_move(Player,X,Y,InitialBoard,FinalBoard):-
    valid_move(X,Y,InitialBoard),
    getY(InitialBoard,Y,L),
    replace(X,L,Player,L2),
    replace(Y, InitialBoard, L2, FinalBoard).

replace(Ind, List, Val, Res) :-
    nth0(Ind, List, _, Aux),
    nth0(Ind, Res, Val, Aux).

%*********AL�NEA E*************%
%generate_move(Player, InitialBoard,FinalBoard).
%Devolve todos os movimentos poss�veis para o jogador Player.

generate_move(Player, InitialBoard, FinalBoard) :-
        length(InitialBoard, L),
        aux1(Player, InitialBoard, FinalBoard, 0, L).


aux1(_,_ ,_ , L, L):-!.
aux1(Player, InitialBoard, FinalBoard, Num,_ ) :-
     findElementInPosition(InitialBoard, Num, List),
     nth0(N, List, 0),
     replace(N, List, Player, Res),
     replace(Num, InitialBoard, Res, FinalBoard).

aux1(Player, InitialBoard, FinalBoard, Num, Len) :-
       N2 is Num+1,
       aux1(Player, InitialBoard, FinalBoard, N2, Len).


findElementInPosition([H|_], 0, H).
findElementInPosition([_|T], Value, L):-
     Value2 is Value-1,
     findElementInPosition(T, Value2, L).



%*********AL�NEA F*************%


% game_over(Board,Winner) - verifica se o jogo terminou e indica o
% vencedor (Winner:
% 0- empate, 1 - computador, 2 - jogador). Este predicado deve verificar
% as diferentes possibilidades de um jogador vencer, bem como verificar
% se j� n�o existem posi��es livres no tabuleiro.
%
%


game_over(Board,W):-  %horizontal
    append(_,[C|_], Board),
    append(_,[W,W,W,W|_],C),
    W =\= 0.

game_over(Board,W):-  %vertical
    transpose(Board, NewBoard),
    append(_,[C|_], NewBoard),
    append(_,[W,W,W,W|_],C),
    W =\= 0.

game_over(Board,W):- %full board
    full_board(Board,W).

game_over(Board,W):-
    append(_,[C1,C2,C3,C4|_],Board), %diagonal
    append(I1,[W|_],C1),
    append(I2,[W|_],C2),
    append(I3,[W|_],C3),
    append(I4,[W|_],C4),
    length(I1,M1), length(I2,M2), length(I3,M3), length(I4,M4),
    M2 is M1+1, M3 is M2+1, M4 is M3+1,
    W =\= 0.

game_over(Board,W):-
    append(_,[C1,C2,C3,C4|_],Board),
    append(I1,[W|_],C1),
    append(I2,[W|_],C2),
    append(I3,[W|_],C3),
    append(I4,[W|_],C4),
    length(I1,M1), length(I2,M2), length(I3,M3), length(I4,M4),
    M2 is M1-1, M3 is M2-1, M4 is M3-1,
    W =\= 0.


full_board(Board,W):-
\+ (append(_,[C|_],Board),
    append(_,[0|_],C)),
    W is 0.

transpose([[]|_], []).
transpose(Matrix, [Row|Rows]) :-
    transpose_1st_col(Matrix, Row, RestMatrix),
    transpose(RestMatrix, Rows).

transpose_1st_col([], [], []).
transpose_1st_col([[H|T]|Rows], [H|Hs], [T|Ts]) :-
    transpose_1st_col(Rows, Hs, Ts).


%*********AL�NEA G*************%

% calculate_board_value(Winner, Score) - permite saber qual o valor do
% tabuleiro na perspectiva do computador sabendo quem foi o vencedor
% (Winner).

calculate_board_value(2, -1).
calculate_board_value(1, 1).
calculate_board_value(0, 0).

%*********AL�NEA H*************%
% calculate_board_heuristic(Player,Board,Value) - permite saber o valor
% de um tabuleiro n�o final atrav�s de uma heur�stica.

calculate_board_heuristic(Player,Board,Value):-
    generate_move(Player,Board,List),
    game_over(List,Player),
    Value is 3,
    !.

calculate_board_heuristic(Player,Board,Value):-
    generate_move(Player,Board,X),
    generate_move(Player,X,Y),
    game_over(Y,Player),
    Value is 1,
    !.

calculate_board_heuristic(_,_,0).


%play/1
%O predicado play tem como argumentos o jogador que deve jogar e o tabuleiro sobre o qual deve fazer a sua jogada.
% Este predicado e' recursivo de modo a permitir a alternancia das
% jogadas. A sua implementa�ao e constituida pela jogada do computador
% (play(1,B)) , pela jogada do jogador (play(2,B)) e pela verifica�ao
% do fim do jogo.
play(_,B0):-
    game_over(B0,T),
    calculate_board_value(T,Value),
    print_board(B0),
    write('Game Over!'),
    nl,
    display(Value),
    !.

play(1,B0):-
    write('Player:'),nl,
    print_board(B0),
    alphabeta(B0,6,-100,100,B1,_,1),
    !,
    play(2,B1).

play(2,B0):-
    write('Computer:'),nl,
    print_board(B0),
    write('Where to play? (C,L)'),
    read(C),
    read(L),
    valid_move(C,L,B0),
    add_move(2,C,L,B0,B1),
    !,
    play(1,B1).

%alphabeta/7
%minimax-alpha-beta
% O predicado que implementa o minimax e' chamado alfabeta e tem como
% argumentos o tabuleiro, o valor de profundidade que ainda e' permitido
% explorar, o alfa, o beta, o tabuleiro resultado, o score da avalia�ao
% do resultado na o'tica do computador e o jogador que se esta' a
% avaliar (minimizar ou a maximizar).
alphabeta(Bi, 0, _, _, Bi, Value, P):-
    calculate_board_heuristic(P,Bi,Value),
    !.

alphabeta(Bi, _, _, _, Bi, Value, _):-
    game_over(Bi,T),
    calculate_board_value(T,Value),
    !.


alphabeta(Bi, D, Alfa, Beta, Bf, Value, Player):-
    next_player(Player,Other),
    possible_moves(Player,Bi,L),
    !,
    evaluate_child(Other, L, D, Alfa, Beta, Bf, Value).

%evaluate_child/7
evaluate_child(Player, [B], D, Alfa, Beta, B, Value):-
    D1 is D-1,
    !,
    alphabeta(B, D1, Alfa, Beta, _, Value, Player).


evaluate_child(2, [Bi|T], D, Alfa, Beta,Bf, Value):-
    D1 is D-1,
    alphabeta(Bi, D1, Alfa, Beta, _, Value1, 2),
    !,
    evaluate_next_child_max(Value1,Bi, T, D, Alfa, Beta, Value, Bf).

evaluate_child(1, [Bi|T], D, Alfa, Beta,Bf, Value):-
    D1 is D-1,
    alphabeta(Bi, D1, Alfa, Beta, _, Value1, 1),
    !,
    evaluate_next_child_min(Value1,Bi, T, D, Alfa, Beta, Value, Bf).

%evaluate_next_child_max/8
evaluate_next_child_max(Value1,Bi, T, D, Alfa, Beta, Value, Bf):-
    Value1 < Beta,
    max(Value1,Alfa,NewAlfa),
    !,
    evaluate_child(2, T, D, NewAlfa, Beta, B2, Value2),
    max_board(Value1,Bi,Value2,B2,Value,Bf).

evaluate_next_child_max(Value1,Bi, _, _, _, _, Value1, Bi):- !.

%evaluate_next_child_min/8
evaluate_next_child_min(Value1,Bi, T, D, Alfa, Beta, Value, Bf):-
     Value1 > Alfa,
     min(Value1,Beta,NewBeta),
     !,
     evaluate_child(1, T, D, Alfa, NewBeta, B2, Value2),
     min_board(Value1,Bi,Value2,B2,Value,Bf).

evaluate_next_child_min(Value1,Bi, _, _, _, _, Value1, Bi):- !.


%possible_moves/3
possible_moves(X,B,L):-
    bagof(BP,generate_move(X,B,BP),L).

%max_board/6
max_board(Value1,B1,Value2,_,Value1,B1):-
    Value1 >= Value2.

max_board(Value1,_,Value2,B2,Value2,B2):-
    Value1 < Value2.

%min_board/6
min_board(Value1,B1,Value2,_,Value1,B1):-
    Value1 =< Value2.

min_board(Value1,_,Value2,B2,Value2,B2):-
    Value1 > Value2.

%max/3
max(X,Y,X):-
    X>=Y,!.
max(X,Y,Y):-
    Y>X.
%min/3
min(X,Y,X):-
    X=<Y,!.
min(X,Y,Y):-
    Y<X.
