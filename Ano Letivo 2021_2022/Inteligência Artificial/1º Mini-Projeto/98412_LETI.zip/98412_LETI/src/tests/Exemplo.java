package tests;

import graph_utils.Graph;
import graph_utils.Node;
/**
 * Example of a graph creation
 * 
 * @author Rita Peixoto
 * @version 1.0
 *
 */
public class Exemplo {
	public static void main(String[] args) {
		/*
		 * (1)--->(2)--->(3) 
		 *  \ 			 / 
		 *   \ 		   	/
		 *    V 	   V 
		 *    (4)--->(5)
		 * 
		 * Initial -> (1) Final -> (5)
		 */

		Graph graph = new Graph();
		// creating the nodes
		Node n6 = new Node("6");
		Node n10 = new Node("10");
		Node n4 = new Node("4");
		Node n3 = new Node("3");
		Node n8 = new Node("8");
		Node n9 = new Node("9");
		Node n11 = new Node("11");
		Node n5 = new Node("5");
		Node n7 = new Node("7");
		Node n2 = new Node("2");
		Node n1 = new Node("1");

		// creating and adding edges to graph
		graph.addEdge(n6, n10);
		graph.addEdge(n10, n4);
		graph.addEdge(n4, n3);
		graph.addEdge(n4, n8);
		graph.addEdge(n8, n5);
		graph.addEdge(n5, n1);
		graph.addEdge(n5, n2);
		graph.addEdge(n5, n11);
		graph.addEdge(n3, n9);
		graph.addEdge(n3, n11);
		graph.addEdge(n9, n11);
		graph.addEdge(n9, n7);
		

		//System.out.println(graph.toString());
		
	}
}
