package search_algorithms;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;
import graph_utils.Edge;
import graph_utils.Graph;
import graph_utils.Node;

public class AStarAlgorithm extends SearchAlgorithm {

	public AStarAlgorithm(Graph graph) {
		super(graph);
	}

	@Override
	public List<Node> start(Node n_initial, Node n_final) {
		List<Node> visited = new ArrayList<Node>();
		List<Node> path = new ArrayList<>();
		PriorityQueue<Node> fila = new PriorityQueue<>((a, b) -> a.getF() - b.getF());
		double g_value = 0;

		fila.add(n_initial);
		visited.add(n_initial);

		while (!fila.isEmpty()) {

			Node currentNode = fila.poll();
			path.add(currentNode);

			if (currentNode.equals(n_final)) {
				return path;
			}
			if (adjacencyOfNode(currentNode) != null) {
				for (Edge e : adjacencyOfNode(currentNode)) {
					Node child = e.getN1();
					double cost = e.getCost();
					double temp_g_value = g_value + cost;
					double temp_f_value = temp_g_value + child.getHeuristic();
					if (!fila.contains(child) || temp_f_value < child.getF()) {
						child.setCost((int) temp_g_value);

						if (fila.contains(child)) {
							fila.remove(child);
						}

						fila.add(child);
					}
					
					if(!visited.contains(e.getN1()))
						visited.add(e.getN1());
						fila.add(e.getN1());
				}
			}
		}
		return path;
	}

}
