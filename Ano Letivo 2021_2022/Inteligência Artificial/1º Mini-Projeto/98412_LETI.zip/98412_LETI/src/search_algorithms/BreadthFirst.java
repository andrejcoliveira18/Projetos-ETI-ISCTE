package search_algorithms;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import graph_utils.Edge;
import graph_utils.Graph;
import graph_utils.Node;

public class BreadthFirst extends SearchAlgorithm{

	public BreadthFirst(Graph graph) {
		super(graph);
	}

	@Override
	public List<Node> start(Node n_initial, Node n_final) {
		Queue<Node> fila = new LinkedList<>();
		List<Node> path = new LinkedList<>();
		List<Node> visited = new LinkedList<>();
		fila.add(n_initial);
		visited.add(n_initial);
		Node currentNode;
		while(!fila.isEmpty()) {
			currentNode = fila.remove();
			path.add(currentNode);
			if(currentNode.equals(n_final)) {
				return path;
			}else {
				if(adjacencyOfNode(currentNode) != null) {
					for(Edge e: adjacencyOfNode(currentNode)) {
						fila.add(e.getN1());
						visited.add(e.getN1());
					}
				}
			}
		}
		return path;
	}
	
}
