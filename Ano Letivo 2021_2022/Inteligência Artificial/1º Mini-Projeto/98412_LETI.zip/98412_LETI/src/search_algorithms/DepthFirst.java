package search_algorithms;

import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

import graph_utils.Edge;
import graph_utils.Graph;
import graph_utils.Node;

public class DepthFirst extends SearchAlgorithm{

	public DepthFirst(Graph graph) {
		super(graph);
	}

	@Override
	public List<Node> start(Node n_initial, Node n_final) {
		Stack<Node> pilha = new Stack<>();
		List<Node> path = new LinkedList<>();
		List<Node> visited = new LinkedList<>();
		pilha.add(n_initial);
		visited.add(n_initial);
		Node currentNode;
		while(!pilha.isEmpty()) {
			currentNode = pilha.pop();
			if(currentNode.equals(n_final)) {
				path.add(n_final);
				return path;
			}else {
				if(adjacencyOfNode(currentNode) != null) {
					for(Edge e: adjacencyOfNode(currentNode)) {
						pilha.add(e.getN1());
						visited.add(e.getN1());
						if(!path.contains(e.getN0()))
							path.add(e.getN0());
					}
				}
			}
		}
		return path;
	}
	

}

