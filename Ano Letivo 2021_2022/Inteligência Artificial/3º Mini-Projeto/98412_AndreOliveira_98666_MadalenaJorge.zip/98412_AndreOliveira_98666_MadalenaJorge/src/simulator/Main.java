package simulator;

import net.sourceforge.jFuzzyLogic.FIS;
import net.sourceforge.jFuzzyLogic.FunctionBlock;
import weka.classifiers.trees.J48;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;

public class Main {
	public static void main(String[] args) throws Exception {
		String filename = "mushroom.fcl";
		FIS fis = FIS.load(filename, true);

		if (fis == null) {
			System.err.println("Can't load file: '" + filename + "'");
			System.exit(1);
		}

		// Get default function block
		FunctionBlock fb = fis.getFunctionBlock(null);
		
		// Get robot simulator
		Simulator sim = new Simulator();
		
		// Get Data Source
		DataSource ds = new DataSource("mushroom.arff");
		
		Instances data = ds.getDataSet();
		data.setClassIndex(data.numAttributes() - 1);
		J48 j48 = new J48();
		j48.buildClassifier(data);
		
		while(true) {
			
			NewInstances ni = new NewInstances(data);
			if(sim.getMushroomAttributes() != null) {
				if(sim.getDistanceC() <= 1) {
					ni.addInstance(sim.getMushroomAttributes());
					Instances i = ni.getDataset();
					Instance m = i.instance(0);
					double d = j48.classifyInstance(m);
					fb.setVariable("toxicity",  d);
					fb.evaluate();
					if(fb.getVariable("action").defuzzify() == 0) {
						sim.setAction(Action.NO_ACTION);
					}else if(fb.getVariable("action").defuzzify() == -1) {
						sim.setAction(Action.DESTROY);
					}else if(fb.getVariable("action").defuzzify() == 1)
						sim.setAction(Action.PICK_UP);
				}
			}else
				sim.setAction(Action.NO_ACTION);
			
			
			fb.setVariable("distance_left",sim.getDistanceL());
			fb.setVariable("distance_right", sim.getDistanceR());
			fb.setVariable("distance_center", sim.getDistanceC());
			
			// Evaluate
			fb.evaluate();
			
			//Get new rotation angle
			double a = fb.getVariable("rotation_angle").defuzzify();
			
			//Get new robot speed
			double s = fb.getVariable("speed").defuzzify();
			
			//Set robot angle
			sim.setRobotAngle(a);
			
			//Set robot speed
			sim.setRobotSpeed((int) s);
			
			//Next simulation step
			sim.step();
		}
	}
}
